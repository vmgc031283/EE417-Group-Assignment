

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AboutusServ
 */
@WebServlet("/AboutusServ")
public class AboutusServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	try {
	PrintWriter out = response.getWriter();
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con = DriverManager.getConnection("jdbc:mysql:///maxtekbankdb","root","Victor@Gonzalez_03?");
	String n=request.getParameter("txtemail");
	
	PreparedStatement ps = con.prepareStatement("INSERT INTO maxtekbankdb.about_us (email) VALUES (?)");
	ps.setString(1,n);

	//executing the query
	int count = ps.executeUpdate();

	if(count==0) {
	out.println("Record not stored into database");
	}

	else {
	out.println("Record Stored into Database");
	}
	
	} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	};


	}

	}

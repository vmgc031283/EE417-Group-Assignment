

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ApplicationServ
 */
@WebServlet("/ApplicationServ")
public class ApplicationServ extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql:///maxtekbankdb","root","Victor@Gonzalez_03?");
			String Phone_No=request.getParameter("Phone_No");
			String email=request.getParameter("email");
			String memo=request.getParameter("memo");
			String amount_5=request.getParameter("amount_5");
			String amount_10=request.getParameter("amount_10");
			String amount_20=request.getParameter("amount_20");
		
			
			
			PreparedStatement ps = con.prepareStatement("INSERT INTO maxtekbankdb.topupmobile (Phone_No,email,Memo,amount_5,amount_10,amount_20) VALUES (?,?,?,?,?,?)");
			ps.setString(1,Phone_No);
			ps.setString(2,email);
			ps.setString(3,memo);
			ps.setString(4,amount_5);
			ps.setString(5,amount_10);
			ps.setString(6,amount_20);
	
			
			ps.executeUpdate();
			  
	        // Close all the connections
	        ps.close();
	        con.close();
			
	        // Get a writer pointer 
            // to display the successful result
            PrintWriter out = response.getWriter();
            out.println("<html><body><b>Successfully Inserted"
                        + "</b></body></html>");
            
			} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			};


			}

			}
